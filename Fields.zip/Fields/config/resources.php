<?php

return [
    'fields' => [
        'index',
        'add',
        'edit',
        'remove'
    ],
    'field-groups' => [
        'index',
        'add',
        'edit',
        'remove'
    ]
];